package br.com.fiap.resource.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.com.fiap.resource.to.VendaTO;

public class VendaDAOImpl implements VendaDAO{
	public static List<VendaTO> listaVenda= null;
	
	public VendaDAOImpl() {
		if(listaVenda == null) {
		listaVenda  = new ArrayList<VendaTO>();
		VendaTO to = new VendaTO();
		
		to.setId(1);
		to.setNome("Miguel");
		to.setValor(200);
		to.setDescricao("microondas");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(2);
		to.setNome("Matheus");
		to.setValor(199);
		to.setDescricao("batedeira");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(3);
		to.setNome("Lucas");
		to.setValor(198);
		to.setDescricao("TV");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(4);
		to.setNome("Thiago");
		to.setValor(197);
		to.setDescricao("mouse");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(5);
		to.setNome("Guilherme");
		to.setValor(194);
		to.setDescricao("monitor");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(6);
		to.setNome("Gabriel");
		to.setValor(193);
		to.setDescricao("fogao");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(7);
		to.setNome("Julia");
		to.setValor(192);
		to.setDescricao("geladeira");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(8);
		to.setNome("Natalia");
		to.setValor(191);
		to.setDescricao("mesa");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(9);
		to.setNome("Elisa");
		to.setValor(191);
		to.setDescricao("pia");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		
		to = new VendaTO();
		to.setId(10);
		to.setNome("Mariana");
		to.setValor(234);
		to.setDescricao("armario");
		to.setData(Calendar.getInstance());
		to.setComprou(true);
		listaVenda.add(to);
		}
		
	}
	
	@Override
	public List<VendaTO> select() {
		return listaVenda;
	}

	@Override
	public VendaTO select(int cod) {
		for (int i = 0; i < listaVenda.size(); i++) {
			if(listaVenda.get(i).getId() == cod) {
				return listaVenda.get(i);
			}
		}
		return null;
	}

	@Override
	public boolean insert(VendaTO venda) {
		if(venda != null) {
			return listaVenda.add(venda);
		}else {
			return false;
		}
	
	}

	@Override
	public boolean update(VendaTO venda) {
		for (int i = 0; i < listaVenda.size(); i++) {
			if(listaVenda.get(i).getId() == venda.getId()) {
				listaVenda.set(i,venda);
			}
		}
		return false;
	}

	@Override
	public void delete(int cod) {
		listaVenda.remove((cod-1));
		
	}
	
	

}
