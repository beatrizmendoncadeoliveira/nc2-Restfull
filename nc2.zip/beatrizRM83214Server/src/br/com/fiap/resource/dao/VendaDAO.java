package br.com.fiap.resource.dao;

import java.util.List;

import br.com.fiap.resource.to.VendaTO;

public interface VendaDAO {
	
	public List<VendaTO> select();
	
	public VendaTO select(int cod);
	
	public boolean insert(VendaTO venda);
	
	public boolean update(VendaTO venda);
	
	public void delete(int cod);

}
