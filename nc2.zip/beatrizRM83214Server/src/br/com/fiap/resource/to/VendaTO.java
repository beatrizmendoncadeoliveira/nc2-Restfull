package br.com.fiap.resource.to;

import java.util.Calendar;

public class VendaTO {
	private int id;
	private String nome;
	private Calendar data;
	private String descricao;
	private double valor;
	private boolean comprou;
	
	
	
	public VendaTO() {
		super();
	}
	
	
	
	public VendaTO(int id, String nome, Calendar data, String descricao, double valor, boolean comprou) {
		super();
		this.id = id;
		this.nome = nome;
		this.data = data;
		this.descricao = descricao;
		this.valor = valor;
		this.comprou = comprou;
	}



	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public boolean isComprou() {
		return comprou;
	}
	public void setComprou(boolean comprou) {
		this.comprou = comprou;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
}
