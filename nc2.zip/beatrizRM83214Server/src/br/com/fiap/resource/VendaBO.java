package br.com.fiap.resource;

import java.util.List;

import br.com.fiap.resource.dao.VendaDAOImpl;
import br.com.fiap.resource.to.VendaTO;

public class VendaBO {
	private VendaDAOImpl dao = null;
	
	public List<VendaTO> listar(){
		dao= new VendaDAOImpl();
		return dao.select();
	}
	
	public VendaTO listar(int id){
		dao = new VendaDAOImpl();
		return dao.select(id);
	}
	
	public boolean cadastrar(VendaTO venda) {
		dao = new VendaDAOImpl();
		return dao.insert(venda);
	}
	
	public boolean atualizar(VendaTO venda) {
		dao = new VendaDAOImpl();
		return dao.update(venda);
	}
	
	public void excluir(int cod) {
		dao = new VendaDAOImpl();
		dao.delete(cod);
	}	
	

}
